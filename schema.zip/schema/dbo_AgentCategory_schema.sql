-- Table: [dbo].[AgentCategory]
-- Row count: 0
-- Generated: 2025-07-07T13:22:48.273670

IF OBJECT_ID('[dbo].[AgentCategory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AgentCategory];

CREATE TABLE [dbo].[AgentCategory] (
    [id] bigint NOT NULL,
    [agent_id] bigint NOT NULL,
    [category_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_AgentCategory] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[AgentCategory]
ADD CONSTRAINT [FK_AgentCategory_category_id_0]
FOREIGN KEY ([category_id]) REFERENCES [dbo].[UrlCategory]([id]);

ALTER TABLE [dbo].[AgentCategory]
ADD CONSTRAINT [FK_AgentCategory_agent_id_1]
FOREIGN KEY ([agent_id]) REFERENCES [dbo].[Agent]([id]);
