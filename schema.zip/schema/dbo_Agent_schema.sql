-- Table: [dbo].[Agent]
-- Row count: 3
-- Generated: 2025-07-07T13:22:48.010677

IF OBJECT_ID('[dbo].[Agent]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Agent];

CREATE TABLE [dbo].[Agent] (
    [id] bigint NOT NULL,
    [agent_name] nvarchar(255) NOT NULL,
    [description] nvarchar(MAX) NOT NULL,
    [input_config_json] nvarchar(MAX),
    [output_config_json] nvarchar(MAX),
    [created_by] bigint NOT NULL,
    [brand_source_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Agent] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[Agent]
ADD CONSTRAINT [FK_Agent_created_by_0]
FOREIGN KEY ([created_by]) REFERENCES [dbo].[User]([id]);

ALTER TABLE [dbo].[Agent]
ADD CONSTRAINT [FK_Agent_brand_source_id_1]
FOREIGN KEY ([brand_source_id]) REFERENCES [dbo].[BrandSource]([id]);
