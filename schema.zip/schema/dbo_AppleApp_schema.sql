-- Table: [dbo].[AppleApp]
-- Row count: 2
-- Generated: 2025-07-07T13:22:48.457245

IF OBJECT_ID('[dbo].[AppleApp]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AppleApp];

CREATE TABLE [dbo].[AppleApp] (
    [id] bigint NOT NULL,
    [app_name] varchar(255) NOT NULL,
    [apple_id] varchar(255) NOT NULL,
    [app_id] varchar(255) NOT NULL,
    [country] varchar(255) NOT NULL,
    [url] varchar(255) NOT NULL,
    [score] varchar(255) NOT NULL,
    [icon] varchar(255) NOT NULL,
    [category_id] bigint NOT NULL,
    [brand_id] bigint NOT NULL,
    [created_at] datetime2,
    [updated_at] datetime2
,
    CONSTRAINT [PK_AppleApp] PRIMARY KEY ([id])
);
