-- Table: [dbo].[AppleReviewSentiment]
-- Row count: 435
-- Generated: 2025-07-07T13:22:48.914403

IF OBJECT_ID('[dbo].[AppleReviewSentiment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AppleReviewSentiment];

CREATE TABLE [dbo].[AppleReviewSentiment] (
    [id] bigint NOT NULL,
    [sentiment_generic] varchar(MAX) NOT NULL,
    [sentiment_category_specific] varchar(MAX) NOT NULL,
    [review_id] bigint NOT NULL,
    [created_at] datetime2,
    [updated_at] datetime2
,
    CONSTRAINT [PK_AppleReviewSentiment] PRIMARY KEY ([id])
);
