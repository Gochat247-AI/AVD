-- Table: [dbo].[AppleReview]
-- Row count: 1109
-- Generated: 2025-07-07T13:22:48.670807

IF OBJECT_ID('[dbo].[AppleReview]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AppleReview];

CREATE TABLE [dbo].[AppleReview] (
    [id] bigint NOT NULL,
    [review_id] varchar(255) NOT NULL,
    [user_name] varchar(255) NOT NULL,
    [user_url] varchar(255) NOT NULL,
    [version] varchar(255) NOT NULL,
    [score] int NOT NULL,
    [title] varchar(MAX) NOT NULL,
    [text] varchar(MAX) NOT NULL,
    [url] varchar(255) NOT NULL,
    [updated] datetime2 NOT NULL,
    [app_id] bigint NOT NULL,
    [created_at] datetime2,
    [updated_at] datetime2
,
    CONSTRAINT [PK_AppleReview] PRIMARY KEY ([id])
);
