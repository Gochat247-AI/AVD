-- Table: [dbo].[BrandRole]
-- Row count: 3
-- Generated: 2025-07-07T13:22:49.216966

IF OBJECT_ID('[dbo].[BrandRole]', 'U') IS NOT NULL
    DROP TABLE [dbo].[BrandRole];

CREATE TABLE [dbo].[BrandRole] (
    [id] bigint NOT NULL,
    [role_id] bigint NOT NULL,
    [brand_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_BrandRole] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[BrandRole]
ADD CONSTRAINT [FK_BrandRole_brand_id_0]
FOREIGN KEY ([brand_id]) REFERENCES [dbo].[Brand]([id]);

ALTER TABLE [dbo].[BrandRole]
ADD CONSTRAINT [FK_BrandRole_role_id_1]
FOREIGN KEY ([role_id]) REFERENCES [dbo].[Role]([id]);
