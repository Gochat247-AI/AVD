-- Table: [dbo].[BrandSource]
-- Row count: 6
-- Generated: 2025-07-07T13:22:49.301529

IF OBJECT_ID('[dbo].[BrandSource]', 'U') IS NOT NULL
    DROP TABLE [dbo].[BrandSource];

CREATE TABLE [dbo].[BrandSource] (
    [id] bigint NOT NULL,
    [source_id] bigint NOT NULL,
    [brand_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_BrandSource] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[BrandSource]
ADD CONSTRAINT [FK_BrandSource_brand_id_0]
FOREIGN KEY ([brand_id]) REFERENCES [dbo].[Brand]([id]);

ALTER TABLE [dbo].[BrandSource]
ADD CONSTRAINT [FK_BrandSource_source_id_1]
FOREIGN KEY ([source_id]) REFERENCES [dbo].[DataSource]([id]);
