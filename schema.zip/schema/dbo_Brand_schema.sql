-- Table: [dbo].[Brand]
-- Row count: 2
-- Generated: 2025-07-07T13:22:49.018387

IF OBJECT_ID('[dbo].[Brand]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Brand];

CREATE TABLE [dbo].[Brand] (
    [id] bigint NOT NULL,
    [brand_name] nvarchar(255) NOT NULL,
    [input_config_json] nvarchar(MAX),
    [output_config_json] nvarchar(MAX),
    [category_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Brand] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[Brand]
ADD CONSTRAINT [FK_Brand_category_id_0]
FOREIGN KEY ([category_id]) REFERENCES [dbo].[Category]([id]);
