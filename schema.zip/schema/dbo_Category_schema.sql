-- Table: [dbo].[Category]
-- Row count: 1
-- Generated: 2025-07-07T13:22:49.396526

IF OBJECT_ID('[dbo].[Category]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Category];

CREATE TABLE [dbo].[Category] (
    [id] bigint NOT NULL,
    [category_name] nvarchar(255) NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Category] PRIMARY KEY ([id])
);
