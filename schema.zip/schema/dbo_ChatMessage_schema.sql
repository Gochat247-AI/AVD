-- Table: [dbo].[ChatMessage]
-- Row count: 205
-- Generated: 2025-07-07T13:22:49.505531

IF OBJECT_ID('[dbo].[ChatMessage]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ChatMessage];

CREATE TABLE [dbo].[ChatMessage] (
    [message_id] varchar(36) NOT NULL,
    [session_id] varchar(36) NOT NULL,
    [sender] varchar(10) NOT NULL,
    [content] nvarchar(MAX) NOT NULL,
    [timestamp] datetime NOT NULL DEFAULT (getdate()),
    [sql_results] nvarchar(MAX),
    [web_results] nvarchar(MAX)
,
    CONSTRAINT [PK_ChatMessage] PRIMARY KEY ([message_id])
);

ALTER TABLE [dbo].[ChatMessage]
ADD CONSTRAINT [FK_ChatMessage_session_id_0]
FOREIGN KEY ([session_id]) REFERENCES [dbo].[ChatSession]([session_id]);
