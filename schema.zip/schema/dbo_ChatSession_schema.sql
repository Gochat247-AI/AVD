-- Table: [dbo].[ChatSession]
-- Row count: 52
-- Generated: 2025-07-07T13:22:50.299917

IF OBJECT_ID('[dbo].[ChatSession]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ChatSession];

CREATE TABLE [dbo].[ChatSession] (
    [session_id] varchar(36) NOT NULL,
    [user_id] varchar(100) NOT NULL,
    [title] varchar(255) DEFAULT ('New Conversation'),
    [created_at] datetime NOT NULL DEFAULT (getdate()),
    [updated_at] datetime NOT NULL DEFAULT (getdate()),
    [is_active] bit DEFAULT ((1)),
    [metadata] nvarchar(MAX)
,
    CONSTRAINT [PK_ChatSession] PRIMARY KEY ([session_id])
);
