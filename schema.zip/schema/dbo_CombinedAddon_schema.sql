-- Table: [dbo].[CombinedAddon]
-- Row count: 338
-- Generated: 2025-07-07T13:22:50.390911

IF OBJECT_ID('[dbo].[CombinedAddon]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedAddon];

CREATE TABLE [dbo].[CombinedAddon] (
    [internal_id] bigint NOT NULL,
    [id] varchar(255) NOT NULL,
    [additional_details] varchar(MAX),
    [amount] int,
    [amount_details] varchar(255),
    [best_seller] varchar(255),
    [billing_cycle] varchar(255),
    [brand_name] varchar(255),
    [description] varchar(MAX),
    [is_new] varchar(255),
    [limited_offer] varchar(255),
    [processed_at] datetime2,
    [product_name] varchar(255),
    [run_id] int,
    [seasonal_offer] varchar(255),
    [segment] varchar(255),
    [url] varchar(255),
    [vat_applicable] varchar(255),
    [vat_included] varchar(255),
    [vat_percentage] int,
    [vat_percentage_details] varchar(255),
    [validity] varchar(255),
    [coverage_amount] varchar(255),
    [coverage_amount_details] varchar(255),
    [validity_details] varchar(255),
    [minutes] varchar(255),
    [minutes_type] varchar(255),
    [data_allowance] varchar(255),
    [data_allowance_details] varchar(255),
    [data_type] varchar(MAX),
    [minutes_details] varchar(255),
    [coverage_types] varchar(MAX)
,
    CONSTRAINT [PK_CombinedAddon] PRIMARY KEY ([internal_id])
);
