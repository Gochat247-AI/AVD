-- Table: [dbo].[CombinedAddonsEmbedding]
-- Row count: 338
-- Generated: 2025-07-07T13:22:50.623910

IF OBJECT_ID('[dbo].[CombinedAddonsEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedAddonsEmbedding];

CREATE TABLE [dbo].[CombinedAddonsEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedAddonsEmbedding] PRIMARY KEY ([id])
);
