-- Table: [dbo].[CombinedBioEmbedding]
-- Row count: 521
-- Generated: 2025-07-07T13:22:51.574617

IF OBJECT_ID('[dbo].[CombinedBioEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedBioEmbedding];

CREATE TABLE [dbo].[CombinedBioEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedBioEmbedding] PRIMARY KEY ([id])
);
