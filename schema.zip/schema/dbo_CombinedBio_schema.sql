-- Table: [dbo].[CombinedBio]
-- Row count: 521
-- Generated: 2025-07-07T13:22:51.455055

IF OBJECT_ID('[dbo].[CombinedBio]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedBio];

CREATE TABLE [dbo].[CombinedBio] (
    [internal_id] bigint NOT NULL,
    [id] varchar(255) NOT NULL,
    [Biography] varchar(MAX),
    [brand_name] varchar(255),
    [processed_at] datetime2,
    [run_id] int,
    [segment] varchar(255),
    [url] varchar(255)
,
    CONSTRAINT [PK_CombinedBio] PRIMARY KEY ([internal_id])
);
