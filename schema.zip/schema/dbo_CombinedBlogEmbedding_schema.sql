-- Table: [dbo].[CombinedBlogEmbedding]
-- Row count: 5
-- Generated: 2025-07-07T13:22:52.797853

IF OBJECT_ID('[dbo].[CombinedBlogEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedBlogEmbedding];

CREATE TABLE [dbo].[CombinedBlogEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedBlogEmbedding] PRIMARY KEY ([id])
);
