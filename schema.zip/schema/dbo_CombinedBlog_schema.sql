-- Table: [dbo].[CombinedBlog]
-- Row count: 5
-- Generated: 2025-07-07T13:22:52.555454

IF OBJECT_ID('[dbo].[CombinedBlog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedBlog];

CREATE TABLE [dbo].[CombinedBlog] (
    [internal_id] bigint NOT NULL,
    [id] varchar(255) NOT NULL,
    [additional_details] varchar(255),
    [brand_name] varchar(255),
    [content] varchar(MAX),
    [processed_at] datetime2,
    [run_id] int,
    [segment] varchar(255),
    [summary] varchar(255),
    [tags] varchar(255),
    [title] varchar(255),
    [url] varchar(255),
    [author] varchar(255),
    [likes] varchar(255),
    [likes_details] varchar(255),
    [publish_date] varchar(255),
    [reading_time] varchar(255),
    [reading_time_details] varchar(255)
,
    CONSTRAINT [PK_CombinedBlog] PRIMARY KEY ([internal_id])
);
