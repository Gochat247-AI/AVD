-- Table: [dbo].[CombinedDevicesEmbedding]
-- Row count: 2282
-- Generated: 2025-07-07T13:22:53.454721

IF OBJECT_ID('[dbo].[CombinedDevicesEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedDevicesEmbedding];

CREATE TABLE [dbo].[CombinedDevicesEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedDevicesEmbedding] PRIMARY KEY ([id])
);
