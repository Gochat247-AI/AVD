-- Table: [dbo].[CombinedDigitalProduct]
-- Row count: 323
-- Generated: 2025-07-07T13:22:56.282756

IF OBJECT_ID('[dbo].[CombinedDigitalProduct]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedDigitalProduct];

CREATE TABLE [dbo].[CombinedDigitalProduct] (
    [internal_id] bigint NOT NULL,
    [id] varchar(255) NOT NULL,
    [access_details] varchar(MAX),
    [additional_benefits] varchar(MAX),
    [additional_details] varchar(MAX),
    [amount] int,
    [amount_details] varchar(255),
    [best_seller] varchar(255),
    [brand_name] varchar(255),
    [content_access] varchar(MAX),
    [description] varchar(MAX),
    [features] varchar(MAX),
    [important_to_know] varchar(MAX),
    [is_new] varchar(255),
    [learn_more_link] varchar(255),
    [limited_offer] varchar(255),
    [processed_at] datetime2,
    [product_name] varchar(255),
    [product_type] varchar(255),
    [promotions] varchar(255),
    [requirements] varchar(MAX),
    [run_id] int,
    [seasonal_offer] varchar(255),
    [segment] varchar(255),
    [sign_up_bonus] varchar(255),
    [support_info] varchar(255),
    [url] varchar(255),
    [vat_included] int,
    [vat_percentage] int,
    [vat_percentage_details] varchar(255),
    [sign_up_bonus_details] varchar(255),
    [images] varchar(255)
,
    CONSTRAINT [PK_CombinedDigitalProduct] PRIMARY KEY ([internal_id])
);
