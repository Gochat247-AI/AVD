-- Table: [dbo].[CombinedDigitalProductsEmbedding]
-- Row count: 323
-- Generated: 2025-07-07T13:22:56.498882

IF OBJECT_ID('[dbo].[CombinedDigitalProductsEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedDigitalProductsEmbedding];

CREATE TABLE [dbo].[CombinedDigitalProductsEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedDigitalProductsEmbedding] PRIMARY KEY ([id])
);
