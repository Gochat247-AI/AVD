-- Table: [dbo].[CombinedPlansEmbedding]
-- Row count: 1001
-- Generated: 2025-07-07T13:22:57.201024

IF OBJECT_ID('[dbo].[CombinedPlansEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedPlansEmbedding];

CREATE TABLE [dbo].[CombinedPlansEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedPlansEmbedding] PRIMARY KEY ([id])
);
