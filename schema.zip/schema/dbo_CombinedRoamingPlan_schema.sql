-- Table: [dbo].[CombinedRoamingPlan]
-- Row count: 410
-- Generated: 2025-07-07T13:22:58.588972

IF OBJECT_ID('[dbo].[CombinedRoamingPlan]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedRoamingPlan];

CREATE TABLE [dbo].[CombinedRoamingPlan] (
    [internal_id] bigint NOT NULL,
    [id] varchar(255) NOT NULL,
    [amount] int,
    [brand_name] varchar(255),
    [bundle] varchar(255),
    [country] varchar(255),
    [currency] varchar(255),
    [processed_at] datetime2,
    [run_id] int,
    [segment] varchar(255),
    [url] varchar(255),
    [vat_included] int,
    [important_notes] varchar(MAX),
    [network_providers] varchar(255),
    [internet_calling_apps] varchar(255)
,
    CONSTRAINT [PK_CombinedRoamingPlan] PRIMARY KEY ([internal_id])
);
