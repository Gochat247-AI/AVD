-- Table: [dbo].[CombinedRoamingPlansEmbedding]
-- Row count: 410
-- Generated: 2025-07-07T13:22:58.852530

IF OBJECT_ID('[dbo].[CombinedRoamingPlansEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedRoamingPlansEmbedding];

CREATE TABLE [dbo].[CombinedRoamingPlansEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedRoamingPlansEmbedding] PRIMARY KEY ([id])
);
