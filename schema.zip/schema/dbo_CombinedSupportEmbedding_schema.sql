-- Table: [dbo].[CombinedSupportEmbedding]
-- Row count: 1805
-- Generated: 2025-07-07T13:22:59.736528

IF OBJECT_ID('[dbo].[CombinedSupportEmbedding]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedSupportEmbedding];

CREATE TABLE [dbo].[CombinedSupportEmbedding] (
    [id] int NOT NULL,
    [original_id] varchar(255),
    [embedding] varchar(MAX)
,
    CONSTRAINT [PK_CombinedSupportEmbedding] PRIMARY KEY ([id])
);
