-- Table: [dbo].[CombinedSupport]
-- Row count: 1805
-- Generated: 2025-07-07T13:22:59.583530

IF OBJECT_ID('[dbo].[CombinedSupport]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CombinedSupport];

CREATE TABLE [dbo].[CombinedSupport] (
    [internal_id] bigint NOT NULL,
    [id] varchar(255) NOT NULL,
    [brand_name] varchar(255),
    [content] varchar(MAX),
    [processed_at] datetime2,
    [question] varchar(255),
    [related_topics] varchar(MAX),
    [run_id] int,
    [segment] varchar(255),
    [type] varchar(255),
    [url] varchar(255),
    [last_updated] varchar(255),
    [additional_details] varchar(MAX),
    [helpful_votes] int,
    [helpful_votes_details] varchar(255),
    [views] int,
    [views_details] varchar(255)
,
    CONSTRAINT [PK_CombinedSupport] PRIMARY KEY ([internal_id])
);
