-- Table: [dbo].[DataSource]
-- Row count: 5
-- Generated: 2025-07-07T13:23:01.759150

IF OBJECT_ID('[dbo].[DataSource]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DataSource];

CREATE TABLE [dbo].[DataSource] (
    [id] bigint NOT NULL,
    [source_name] nvarchar(255) NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_DataSource] PRIMARY KEY ([id])
);
