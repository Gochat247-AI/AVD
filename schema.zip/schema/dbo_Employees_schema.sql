-- Table: [dbo].[Employees]
-- Row count: 0
-- Generated: 2025-07-07T13:23:01.853153

IF OBJECT_ID('[dbo].[Employees]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Employees];

CREATE TABLE [dbo].[Employees] (
    [EmployeeID] int NOT NULL,
    [FirstName] nvarchar(50) NOT NULL,
    [LastName] nvarchar(50) NOT NULL,
    [BirthDate] date,
    [HireDate] date NOT NULL,
    [Salary] decimal(18,2)
,
    CONSTRAINT [PK_Employees] PRIMARY KEY ([EmployeeID])
);
