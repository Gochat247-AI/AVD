-- Table: [dbo].[FailedJob]
-- Row count: 69
-- Generated: 2025-07-07T13:23:01.922086

IF OBJECT_ID('[dbo].[FailedJob]', 'U') IS NOT NULL
    DROP TABLE [dbo].[FailedJob];

CREATE TABLE [dbo].[FailedJob] (
    [id] bigint NOT NULL,
    [uuid] nvarchar(255) NOT NULL,
    [connection] nvarchar(MAX) NOT NULL,
    [queue] nvarchar(MAX) NOT NULL,
    [payload] nvarchar(MAX) NOT NULL,
    [exception] nvarchar(MAX) NOT NULL,
    [failed_at] datetime NOT NULL DEFAULT (getdate())
,
    CONSTRAINT [PK_FailedJob] PRIMARY KEY ([id])
);
