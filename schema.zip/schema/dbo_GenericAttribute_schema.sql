-- Table: [dbo].[GenericAttribute]
-- Row count: 1
-- Generated: 2025-07-07T13:23:02.178090

IF OBJECT_ID('[dbo].[GenericAttribute]', 'U') IS NOT NULL
    DROP TABLE [dbo].[GenericAttribute];

CREATE TABLE [dbo].[GenericAttribute] (
    [id] bigint NOT NULL,
    [attribute_name] nvarchar(MAX) NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_GenericAttribute] PRIMARY KEY ([id])
);
