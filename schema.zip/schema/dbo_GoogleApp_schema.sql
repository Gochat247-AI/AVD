-- Table: [dbo].[GoogleApp]
-- Row count: 2
-- Generated: 2025-07-07T13:23:02.275079

IF OBJECT_ID('[dbo].[GoogleApp]', 'U') IS NOT NULL
    DROP TABLE [dbo].[GoogleApp];

CREATE TABLE [dbo].[GoogleApp] (
    [id] bigint NOT NULL,
    [app_name] varchar(255) NOT NULL,
    [google_id] varchar(255) NOT NULL,
    [country] varchar(255) NOT NULL,
    [url] varchar(255) NOT NULL,
    [score] varchar(255) NOT NULL,
    [installs_text] varchar(255) NOT NULL,
    [cover] varchar(255) NOT NULL,
    [icon] varchar(255) NOT NULL,
    [category_id] bigint NOT NULL,
    [brand_id] bigint NOT NULL,
    [created_at] datetime2,
    [updated_at] datetime2
,
    CONSTRAINT [PK_GoogleApp] PRIMARY KEY ([id])
);
