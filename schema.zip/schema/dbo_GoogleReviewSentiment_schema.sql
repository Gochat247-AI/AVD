-- Table: [dbo].[GoogleReviewSentiment]
-- Row count: 920
-- Generated: 2025-07-07T13:23:02.619126

IF OBJECT_ID('[dbo].[GoogleReviewSentiment]', 'U') IS NOT NULL
    DROP TABLE [dbo].[GoogleReviewSentiment];

CREATE TABLE [dbo].[GoogleReviewSentiment] (
    [id] bigint NOT NULL,
    [sentiment_generic] varchar(MAX) NOT NULL,
    [sentiment_category_specific] varchar(MAX) NOT NULL,
    [review_id] bigint NOT NULL,
    [created_at] datetime2,
    [updated_at] datetime2
,
    CONSTRAINT [PK_GoogleReviewSentiment] PRIMARY KEY ([id])
);
