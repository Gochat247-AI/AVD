-- Table: [dbo].[GoogleReview]
-- Row count: 4852
-- Generated: 2025-07-07T13:23:02.370074

IF OBJECT_ID('[dbo].[GoogleReview]', 'U') IS NOT NULL
    DROP TABLE [dbo].[GoogleReview];

CREATE TABLE [dbo].[GoogleReview] (
    [id] bigint NOT NULL,
    [google_id] varchar(255) NOT NULL,
    [review_id] varchar(255) NOT NULL,
    [user_name] varchar(255) NOT NULL,
    [text] varchar(MAX) NOT NULL,
    [avatar_url] varchar(255),
    [date] datetime2,
    [score] int NOT NULL,
    [count_likes] int,
    [app_version] varchar(255),
    [source] varchar(255),
    [app_id] bigint NOT NULL,
    [created_at] datetime2,
    [updated_at] datetime2
,
    CONSTRAINT [PK_GoogleReview] PRIMARY KEY ([id])
);
