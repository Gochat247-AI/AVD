-- Table: [dbo].[Job]
-- Row count: 0
-- Generated: 2025-07-07T13:23:02.867119

IF OBJECT_ID('[dbo].[Job]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Job];

CREATE TABLE [dbo].[Job] (
    [id] bigint NOT NULL,
    [queue] nvarchar(255) NOT NULL,
    [payload] nvarchar(MAX) NOT NULL,
    [attempts] tinyint NOT NULL,
    [reserved_at] int,
    [available_at] int NOT NULL,
    [created_at] int NOT NULL
,
    CONSTRAINT [PK_Job] PRIMARY KEY ([id])
);
