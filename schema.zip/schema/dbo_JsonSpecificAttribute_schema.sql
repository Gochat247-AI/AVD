-- Table: [dbo].[JsonSpecificAttribute]
-- Row count: 1
-- Generated: 2025-07-07T13:23:02.956121

IF OBJECT_ID('[dbo].[JsonSpecificAttribute]', 'U') IS NOT NULL
    DROP TABLE [dbo].[JsonSpecificAttribute];

CREATE TABLE [dbo].[JsonSpecificAttribute] (
    [id] bigint NOT NULL,
    [json_specific_attribute] nvarchar(MAX) NOT NULL,
    [category_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_JsonSpecificAttribute] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[JsonSpecificAttribute]
ADD CONSTRAINT [FK_JsonSpecificAttribute_category_id_0]
FOREIGN KEY ([category_id]) REFERENCES [dbo].[Category]([id]);
