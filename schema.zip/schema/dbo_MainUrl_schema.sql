-- Table: [dbo].[MainUrl]
-- Row count: 38
-- Generated: 2025-07-07T13:23:03.179678

IF OBJECT_ID('[dbo].[MainUrl]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MainUrl];

CREATE TABLE [dbo].[MainUrl] (
    [id] bigint NOT NULL,
    [url] nvarchar(255) NOT NULL,
    [urls_count] nvarchar(255),
    [brand_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime,
    [agent_id] bigint
,
    CONSTRAINT [PK_MainUrl] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[MainUrl]
ADD CONSTRAINT [FK_MainUrl_agent_id_0]
FOREIGN KEY ([agent_id]) REFERENCES [dbo].[Agent]([id]);

ALTER TABLE [dbo].[MainUrl]
ADD CONSTRAINT [FK_MainUrl_brand_id_1]
FOREIGN KEY ([brand_id]) REFERENCES [dbo].[Brand]([id]);
