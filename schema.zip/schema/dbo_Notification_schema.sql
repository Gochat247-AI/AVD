-- Table: [dbo].[Notification]
-- Row count: 115
-- Generated: 2025-07-07T13:23:03.330748

IF OBJECT_ID('[dbo].[Notification]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Notification];

CREATE TABLE [dbo].[Notification] (
    [id] uniqueidentifier NOT NULL,
    [type] nvarchar(255) NOT NULL,
    [notifiable_type] nvarchar(255) NOT NULL,
    [notifiable_id] bigint NOT NULL,
    [data] nvarchar(MAX) NOT NULL,
    [read_at] datetime,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Notification] PRIMARY KEY ([id])
);
