-- Table: [dbo].[PasswordResetToken]
-- Row count: 0
-- Generated: 2025-07-07T13:23:03.549629

IF OBJECT_ID('[dbo].[PasswordResetToken]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PasswordResetToken];

CREATE TABLE [dbo].[PasswordResetToken] (
    [email] nvarchar(255) NOT NULL,
    [token] nvarchar(255) NOT NULL,
    [created_at] datetime
,
    CONSTRAINT [PK_PasswordResetToken] PRIMARY KEY ([email])
);
