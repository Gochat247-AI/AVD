-- Table: [dbo].[PermissionRole]
-- Row count: 111
-- Generated: 2025-07-07T13:23:03.699629

IF OBJECT_ID('[dbo].[PermissionRole]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PermissionRole];

CREATE TABLE [dbo].[PermissionRole] (
    [permission_id] bigint NOT NULL,
    [role_id] bigint NOT NULL
,
    CONSTRAINT [PK_PermissionRole] PRIMARY KEY ([permission_id], [role_id])
);

ALTER TABLE [dbo].[PermissionRole]
ADD CONSTRAINT [FK_PermissionRole_permission_id_0]
FOREIGN KEY ([permission_id]) REFERENCES [dbo].[Permission]([id]);

ALTER TABLE [dbo].[PermissionRole]
ADD CONSTRAINT [FK_PermissionRole_role_id_1]
FOREIGN KEY ([role_id]) REFERENCES [dbo].[Role]([id]);
