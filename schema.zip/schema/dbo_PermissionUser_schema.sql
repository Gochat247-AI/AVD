-- Table: [dbo].[PermissionUser]
-- Row count: 0
-- Generated: 2025-07-07T13:23:03.785630

IF OBJECT_ID('[dbo].[PermissionUser]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PermissionUser];

CREATE TABLE [dbo].[PermissionUser] (
    [permission_id] bigint NOT NULL,
    [user_id] bigint NOT NULL,
    [user_type] nvarchar(255) NOT NULL
,
    CONSTRAINT [PK_PermissionUser] PRIMARY KEY ([user_id], [permission_id], [user_type])
);

ALTER TABLE [dbo].[PermissionUser]
ADD CONSTRAINT [FK_PermissionUser_permission_id_0]
FOREIGN KEY ([permission_id]) REFERENCES [dbo].[Permission]([id]);
