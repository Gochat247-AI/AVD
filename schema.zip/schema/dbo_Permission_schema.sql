-- Table: [dbo].[Permission]
-- Row count: 54
-- Generated: 2025-07-07T13:23:03.611636

IF OBJECT_ID('[dbo].[Permission]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Permission];

CREATE TABLE [dbo].[Permission] (
    [id] bigint NOT NULL,
    [name] nvarchar(255) NOT NULL,
    [display_name] nvarchar(255),
    [description] nvarchar(255),
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Permission] PRIMARY KEY ([id])
);
