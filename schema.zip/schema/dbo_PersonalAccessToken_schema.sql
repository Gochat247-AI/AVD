-- Table: [dbo].[PersonalAccessToken]
-- Row count: 0
-- Generated: 2025-07-07T13:23:03.845629

IF OBJECT_ID('[dbo].[PersonalAccessToken]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PersonalAccessToken];

CREATE TABLE [dbo].[PersonalAccessToken] (
    [id] bigint NOT NULL,
    [tokenable_type] nvarchar(255) NOT NULL,
    [tokenable_id] bigint NOT NULL,
    [name] nvarchar(255) NOT NULL,
    [token] nvarchar(64) NOT NULL,
    [abilities] nvarchar(MAX),
    [last_used_at] datetime,
    [expires_at] datetime,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_PersonalAccessToken] PRIMARY KEY ([id])
);
