-- Table: [dbo].[Prompt]
-- Row count: 1
-- Generated: 2025-07-07T13:23:04.058053

IF OBJECT_ID('[dbo].[Prompt]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Prompt];

CREATE TABLE [dbo].[Prompt] (
    [id] bigint NOT NULL,
    [prompt_name] nvarchar(255) NOT NULL,
    [prompt_description] nvarchar(MAX) NOT NULL,
    [prompt] nvarchar(MAX) NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Prompt] PRIMARY KEY ([id])
);
