-- Table: [dbo].[RoleUser]
-- Row count: 3
-- Generated: 2025-07-07T13:23:04.361786

IF OBJECT_ID('[dbo].[RoleUser]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RoleUser];

CREATE TABLE [dbo].[RoleUser] (
    [role_id] bigint NOT NULL,
    [user_id] bigint NOT NULL,
    [user_type] nvarchar(255) NOT NULL
,
    CONSTRAINT [PK_RoleUser] PRIMARY KEY ([user_id], [role_id], [user_type])
);

ALTER TABLE [dbo].[RoleUser]
ADD CONSTRAINT [FK_RoleUser_role_id_0]
FOREIGN KEY ([role_id]) REFERENCES [dbo].[Role]([id]);
