-- Table: [dbo].[Role]
-- Row count: 3
-- Generated: 2025-07-07T13:23:04.274772

IF OBJECT_ID('[dbo].[Role]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Role];

CREATE TABLE [dbo].[Role] (
    [id] bigint NOT NULL,
    [name] nvarchar(255) NOT NULL,
    [display_name] nvarchar(255),
    [description] nvarchar(255),
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Role] PRIMARY KEY ([id])
);
