-- Table: [dbo].[Run]
-- Row count: 6
-- Generated: 2025-07-07T13:23:04.454786

IF OBJECT_ID('[dbo].[Run]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Run];

CREATE TABLE [dbo].[Run] (
    [id] bigint NOT NULL,
    [categories] nvarchar(255),
    [start_time] datetime,
    [end_time] datetime,
    [status] nvarchar(255),
    [total_urls] nvarchar(255),
    [finished_urls] nvarchar(255),
    [run_method] nvarchar(255),
    [brand_id] bigint NOT NULL,
    [agent_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Run] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[Run]
ADD CONSTRAINT [FK_Run_agent_id_0]
FOREIGN KEY ([agent_id]) REFERENCES [dbo].[Agent]([id]);

ALTER TABLE [dbo].[Run]
ADD CONSTRAINT [FK_Run_brand_id_1]
FOREIGN KEY ([brand_id]) REFERENCES [dbo].[Brand]([id]);
