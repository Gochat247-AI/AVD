-- Table: [dbo].[SpecificAttributeCategory]
-- Row count: 6
-- Generated: 2025-07-07T13:23:04.870779

IF OBJECT_ID('[dbo].[SpecificAttributeCategory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SpecificAttributeCategory];

CREATE TABLE [dbo].[SpecificAttributeCategory] (
    [id] bigint NOT NULL,
    [category_id] bigint NOT NULL,
    [attribute_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_SpecificAttributeCategory] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[SpecificAttributeCategory]
ADD CONSTRAINT [FK_SpecificAttributeCategory_attribute_id_0]
FOREIGN KEY ([attribute_id]) REFERENCES [dbo].[SpecificAttribute]([id]);

ALTER TABLE [dbo].[SpecificAttributeCategory]
ADD CONSTRAINT [FK_SpecificAttributeCategory_category_id_1]
FOREIGN KEY ([category_id]) REFERENCES [dbo].[Category]([id]);
