-- Table: [dbo].[SpecificAttribute]
-- Row count: 85
-- Generated: 2025-07-07T13:23:04.664777

IF OBJECT_ID('[dbo].[SpecificAttribute]', 'U') IS NOT NULL
    DROP TABLE [dbo].[SpecificAttribute];

CREATE TABLE [dbo].[SpecificAttribute] (
    [id] bigint NOT NULL,
    [attribute_name] nvarchar(255) NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_SpecificAttribute] PRIMARY KEY ([id])
);
