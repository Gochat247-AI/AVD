-- Table: [dbo].[UrlCategory]
-- Row count: 0
-- Generated: 2025-07-07T13:23:05.188770

IF OBJECT_ID('[dbo].[UrlCategory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UrlCategory];

CREATE TABLE [dbo].[UrlCategory] (
    [id] bigint NOT NULL,
    [category_name] nvarchar(255) NOT NULL,
    [category_description] nvarchar(MAX) NOT NULL,
    [brand_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_UrlCategory] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[UrlCategory]
ADD CONSTRAINT [FK_UrlCategory_brand_id_0]
FOREIGN KEY ([brand_id]) REFERENCES [dbo].[Brand]([id]);
