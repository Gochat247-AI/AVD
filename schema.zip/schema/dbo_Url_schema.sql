-- Table: [dbo].[Url]
-- Row count: 6624
-- Generated: 2025-07-07T13:23:04.971778

IF OBJECT_ID('[dbo].[Url]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Url];

CREATE TABLE [dbo].[Url] (
    [url_id] int NOT NULL,
    [url] nvarchar(255) NOT NULL,
    [status] nvarchar(50),
    [error_message] nvarchar(MAX),
    [url_type] nvarchar(50),
    [category] nvarchar(50),
    [availability] nvarchar(254),
    [brand_id] bigint NOT NULL,
    [agent_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_Url] PRIMARY KEY ([url_id])
);

ALTER TABLE [dbo].[Url]
ADD CONSTRAINT [FK_Url_agent_id_0]
FOREIGN KEY ([agent_id]) REFERENCES [dbo].[Agent]([id]);

ALTER TABLE [dbo].[Url]
ADD CONSTRAINT [FK_Url_brand_id_1]
FOREIGN KEY ([brand_id]) REFERENCES [dbo].[Brand]([id]);
