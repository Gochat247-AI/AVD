-- Table: [dbo].[UserJob]
-- Row count: 55
-- Generated: 2025-07-07T13:23:05.346854

IF OBJECT_ID('[dbo].[UserJob]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserJob];

CREATE TABLE [dbo].[UserJob] (
    [id] bigint NOT NULL,
    [job_id] nvarchar(255) NOT NULL,
    [status] nvarchar(255) NOT NULL DEFAULT ('processing'),
    [request_type] nvarchar(255) NOT NULL,
    [request_count] int NOT NULL DEFAULT ('0'),
    [completed_count] int NOT NULL DEFAULT ('0'),
    [taskable_id] bigint NOT NULL,
    [taskable_type] nvarchar(255) NOT NULL,
    [user_id] bigint NOT NULL,
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_UserJob] PRIMARY KEY ([id])
);

ALTER TABLE [dbo].[UserJob]
ADD CONSTRAINT [FK_UserJob_user_id_0]
FOREIGN KEY ([user_id]) REFERENCES [dbo].[User]([id]);
