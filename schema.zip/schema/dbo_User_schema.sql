-- Table: [dbo].[User]
-- Row count: 3
-- Generated: 2025-07-07T13:23:05.250774

IF OBJECT_ID('[dbo].[User]', 'U') IS NOT NULL
    DROP TABLE [dbo].[User];

CREATE TABLE [dbo].[User] (
    [id] bigint NOT NULL,
    [name] nvarchar(255) NOT NULL,
    [email] nvarchar(255) NOT NULL,
    [email_verified_at] datetime,
    [password] nvarchar(255) NOT NULL,
    [remember_token] nvarchar(100),
    [user_image] nvarchar(255) NOT NULL,
    [user_token] int NOT NULL DEFAULT ('10000'),
    [created_at] datetime,
    [updated_at] datetime
,
    CONSTRAINT [PK_User] PRIMARY KEY ([id])
);
