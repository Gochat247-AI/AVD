-- Table: [dbo].[migrations]
-- Row count: 0
-- Generated: 2025-07-07T13:23:03.268690

IF OBJECT_ID('[dbo].[migrations]', 'U') IS NOT NULL
    DROP TABLE [dbo].[migrations];

CREATE TABLE [dbo].[migrations] (
    [id] int NOT NULL,
    [migration] nvarchar(255) NOT NULL,
    [batch] int NOT NULL
,
    CONSTRAINT [PK_migrations] PRIMARY KEY ([id])
);
